#!/bin/bash
echo "****************************************************"
echo "CURL -> CODAS UGR"
echo "****************************************************"
curl -o /dev/null -s -w "Hora de la peticion: $(TZ='Europe/Madrid' date)\nCodigo de respuesta HTTP: %{http_code}\nDNS: %{time_namelookup}s\nConexion: %{time_connect}s\nTiempo hasta el primer byte: %{time_starttransfer}s\nTiempo total: %{time_total}s\nVelocidad de descarga: %{speed_download} BPS\n" https://codas.ugr.es
echo "\n"