#!/bin/bash
echo "****************************************************"
echo "CURL -> RedIRIS Madrid"
echo "****************************************************"
pscheduler task http --url https://130.206.191.13/pscheduler
echo "Timestamp medición:[$(TZ='Europe/Madrid' date '+%c')]"
echo "\n"
