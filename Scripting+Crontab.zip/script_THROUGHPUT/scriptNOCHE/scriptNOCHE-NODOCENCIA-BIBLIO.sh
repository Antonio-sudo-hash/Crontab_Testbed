#!/bin/bash

# Leer los nuevos valores desde prueba3.txt
mapfile -t valores < prueba4.txt

# Verificar que haya exactamente 8
if [ "${#valores[@]}" -ne 6 ]; then
    echo "Error: prueba3.txt debe contener exactamente 8 valores."
    exit 1
fi

# Leer reorganizado.txt en un array existente
mapfile -t reorganizado < reorganizado.txt

# Validar tamaño mínimo
if [ "${#reorganizado[@]}" -lt 179 ]; then
    echo "Error: reorganizado.txt debe tener al menos 437 líneas. Genera el primer bloque primero."
    exit 1
fi

# Puntos de inicio para el segundo bloque
starts=(29)

# Insertar los valores en las posiciones correspondientes sin tocar el resto
for ((block=0; block<1; block++)); do
    start_row=${starts[$block]}
    for ((i=0; i<6; i++)); do
        orig_index=$((block * 6 + i))
        line_number=$((start_row + i * 30))
        reorganizado[$((line_number - 1))]=${valores[$orig_index]}  # -1 porque bash indexa desde 0
    done
done

# Guardar el archivo modificado
> reorganizado.txt
for line in "${reorganizado[@]}"; do
    echo "$line" >> reorganizado.txt
done

