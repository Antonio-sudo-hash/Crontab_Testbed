#!/bin/bash

# Leer los valores originales desde prueba.txt
mapfile -t valores < prueba.txt

# Verificación: deben haber exactamente 32 valores
if [ "${#valores[@]}" -ne 24 ]; then
    echo "Error: prueba.txt debe contener exactamente 32 líneas (valores)."
    exit 1
fi

# Inicializar un array de 434 líneas con "0"
for ((i=0; i<=181; i++)); do
    resultado[$i]=0
done

# Posiciones de inicio para cada bloque de 8 valores
starts=(1 3 5 7)

# Reorganizar los valores
for ((block=0; block<4; block++)); do
    start_row=${starts[$block]}
    for ((i=0; i<6; i++)); do
        orig_index=$((block * 6 + i))
        line_number=$((start_row + i * 30))
        resultado[$line_number]=${valores[$orig_index]}
    done
done

# Escribir el resultado a reorganizado.txt
> reorganizado.txt  # Vaciar si ya existe
for ((i=1; i<=181; i++)); do
    echo "${resultado[$i]}" >> reorganizado.txt
done


