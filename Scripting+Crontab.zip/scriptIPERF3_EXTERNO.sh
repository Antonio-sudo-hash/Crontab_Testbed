#!/bin/bash
echo "****************************************************"
echo "IPERF3 -> RedIRIS Madrid"
echo "****************************************************"
pscheduler task throughput --dest 130.206.191.13
echo "Timestamp medición:[$(TZ='Europe/Madrid' date '+%c')]"
echo "\n"

