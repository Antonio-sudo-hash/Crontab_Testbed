#!/bin/bash

# Leer los nuevos valores desde prueba2.txt
mapfile -t valores < prueba2.txt

# Verificar que haya exactamente 24
if [ "${#valores[@]}" -ne 24 ]; then
    echo "Error: Debe contener exactamente 24 valores."
    exit 1
fi

# Leer reorganizado.txt en un array existente
mapfile -t reorganizado < reorganizado.txt

# Validar tamaño mínimo
if [ "${#reorganizado[@]}" -lt 355 ]; then
    echo "Error: reorganizado.txt debe tener al menos 335 líneas. Genera el primer bloque primero."
    exit 1
fi

# Puntos de inicio para el segundo bloque
starts=(23 27 31 35)

# Insertar los valores en las posiciones correspondientes sin tocar el resto
for ((block=0; block<4; block++)); do
    start_row=${starts[$block]}
    for ((i=0; i<6; i++)); do
        orig_index=$((block * 6 + i))
        line_number=$((start_row + i * 60))
        reorganizado[$((line_number - 1))]=${valores[$orig_index]}  # -1 porque bash indexa desde 0
    done
done

# Guardar el archivo modificado
> reorganizado.txt
for line in "${reorganizado[@]}"; do
    echo "$line" >> reorganizado.txt
done

