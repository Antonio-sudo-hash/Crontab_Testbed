#!/bin/bash
echo "****************************************************"
echo "PING -> CODAS UGR"
echo "****************************************************"
ping -c 10 codas.ugr.es
echo "Timestamp medición: [$(TZ='Europe/Madrid' date '+%c')]"
echo "\n"